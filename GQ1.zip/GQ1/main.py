import pygame
from sprites import *
from config import *
import sys

pygame.font.init()

class game:
    def __init__(self):
        pygame.init
        self.screen = pygame.display.set_mode((Win_Width, Win_Height,))
        self.clock = pygame.time.Clock()
        self.running = True

        self.character_spritesheet = Spritesheet("assets/texture/player.png")
        self.candy_spritesheet = Spritesheet("assets/texture/candy.png")
        self.terrain_spritesheet = Spritesheet("assets/texture/terrain.png")
        self.zombie_spritesheet = Spritesheet("assets/texture/zombie.png")
        self.ghost_spritesheet = Spritesheet("assets/texture/ghost.png")
        self.werewolf_spritesheet = Spritesheet("assets/texture/werewolf.png")
        self.imp_spritesheet = Spritesheet("assets/texture/imp.png")
        self.skeleton_spritesheet = Spritesheet("assets/texture/skeleton.png")
        self.vampire_spritesheet = Spritesheet("assets/texture/vampire.png")

    def createGround(self):
        for y, row in enumerate(groundmap):
            for x, column in enumerate(row):
                if column == ".":
                    Grass(self, x, y)
                elif column == ":":
                    Street(self, x, y)
                elif column == ";":
                    SideWalk(self, x, y)
                elif column == ",":
                    Path(self, x, y)

    def createTilemap(self):
        for i, row in enumerate(tilemap):
            for j, column in enumerate(row):
                if column == "F":
                    TreeForest(self, j, i)
                elif column == "L":
                    TreeBot(self, j, i)
                elif column == "T":
                    TreeTop (self, j, i)
                elif column == "B":
                    Bush(self, j, i)
                elif column == "J":
                    LampBot(self, j, i)
                elif column == "X":
                    FenceX(self, j, i)
                elif column == "Y":
                    FenceY(self, j, i)
                elif column == "1":
                    House1(self, j, i)
                elif column == "2":
                    House2(self, j, i)
                elif column == "3":
                    House3(self, j, i)
                elif column == "4":
                    House4(self, j, i)
                elif column == "5":
                    House5(self, j, i)
                elif column == "6":
                    House6(self, j, i)
                elif column == "7":
                    House7(self, j, i)
                elif column == "8":
                    House8(self, j, i)
                elif column == "9":
                    House9(self, j, i)
                elif column == "0":
                    HouseD(self, j, i)
                elif column == "+":
                    HouseWB(self, j, i)
                elif column == "/":
                    HouseWM(self, j, i)
                elif column == "-":
                    HouseWT(self, j, i)
                elif column == "P":
                    Player(self, j, i)
                elif column == "Z":
                    Zombie(self, j, i)
                elif column == "G":
                    Ghost(self, j, i)
                elif column == "W":
                    Werewolf(self, j, i)
                elif column == "I":
                    Imp(self, j, i)
                elif column == "V":
                    Vampire(self, j, i)
                elif column == "S":
                    Skeleton(self, j, i)
                elif column == "C":
                    Candy(self,j,i)

    def createDecoration(self):
        for y, row in enumerate(decomap):
            for x, column in enumerate(row):
                if column == "[":
                    Roof1(self, x, y)
                elif column == "|":
                    Roof2(self, x, y)
                elif column == "]":
                    Roof3(self, x, y)
                elif column == "{":
                    Tree(self, x, y)
                elif column == "}":
                    LampTop(self, x, y)

    def new(self):
        self.playing=True

        self.all_sprites = pygame.sprite.LayeredUpdates()
        self.blocks = pygame.sprite.LayeredUpdates()
        self.enemies = pygame.sprite.LayeredUpdates()
        self.player = pygame.sprite.LayeredUpdates()
        self.candy = pygame.sprite.LayeredUpdates()

        self.createGround()
        self.createTilemap()
        self.createDecoration()
        
    def events(self):
        for events in pygame.event.get():
            if events.type == pygame.QUIT:
                self.playing =False
                self.running = False

    def update(self):
        self.all_sprites.update()

    def draw(self):
        self.screen.fill(BLACK)
        self.all_sprites.draw(self.screen)
        self.clock.tick(FPS)
        pygame.display.update()
    
    def main(self):
        while self.playing:
            self.events()
            self.update()
            self.draw()
        self.running=False

    def gameover(self):
        pass

    def introscreen(self):
        pass


g=game()
g.introscreen()
g.new()
while g.running:
    g.main()
    g.gameover()

pygame.quit()
sys.exit()