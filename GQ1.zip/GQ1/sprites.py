import pygame
from config import *
import math
import random

class Spritesheet:
    def __init__(self, file):
        self.sheet = pygame.image.load(file).convert_alpha()

    def get_sprite(self, x, y, width, height):
        sprite = pygame.Surface([width, height])
        sprite.blit(self.sheet, (0,0), (x, y, width, height))
        sprite.set_colorkey(BLACK)
        return sprite

class Player(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game=game
        self._layer=Player_Layer
        self.groups=self.game.all_sprites, self.game.player
        pygame.sprite.Sprite.__init__(self, self.groups)
        self._leftcandy = LeftCandy

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.x_change=0
        self.y_change=0

        self.facing = "down"
        self.animation_loop = 1

        self.image = self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

        self.down_animations = [self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height),
        self.game.character_spritesheet.get_sprite(64, 0, self.width, self.height),
        self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height),
        self.game.character_spritesheet.get_sprite(128, 0, self.width, self.height),
        self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height),]

        self.up_animations =  [self.game.character_spritesheet.get_sprite(0, 64, self.width, self.height),
        self.game.character_spritesheet.get_sprite(64, 64, self.width, self.height),
        self.game.character_spritesheet.get_sprite(0, 64, self.width, self.height),
        self.game.character_spritesheet.get_sprite(128, 64, self.width, self.height),
        self.game.character_spritesheet.get_sprite(0, 64, self.width, self.height),]

        self.left_animations = [self.game.character_spritesheet.get_sprite(0, 128, self.width, self.height),
        self.game.character_spritesheet.get_sprite(64, 128, self.width, self.height),
        self.game.character_spritesheet.get_sprite(0, 128, self.width, self.height),
        self.game.character_spritesheet.get_sprite(128, 128, self.width, self.height),
        self.game.character_spritesheet.get_sprite(0, 128, self.width, self.height),]

        self.right_animations = [self.game.character_spritesheet.get_sprite(0, 192, self.width, self.height),
        self.game.character_spritesheet.get_sprite(64, 192, self.width, self.height),
        self.game.character_spritesheet.get_sprite(0, 192, self.width, self.height),
        self.game.character_spritesheet.get_sprite(128, 192, self.width, self.height),
        self.game.character_spritesheet.get_sprite(0, 192, self.width, self.height),]

    def update(self):
        self.movement()
        self.animate()
        self.collide_enemy()
        self.collide_candy()
        
        self.rect.x += self.x_change
        self.collide_blocks("x")
        self.rect.y += self.y_change
        self.collide_blocks("y")

        self.x_change = 0
        self.y_change = 0

    def collide_enemy(self):
        hits = pygame.sprite.spritecollide(self, self.game.enemies, False)
        if hits:
            pygame.time.delay(3000)
            self.kill()
            self.game.playing = False

    def collide_candy(self):
        picks = pygame.sprite.spritecollide(self, self.game.candy, False)
        if picks:
            print("Homelo Chino")
            self._leftcandy -=1
            if self._leftcandy == 0:
                self.game.playing = False

    def movement(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            for sprite in self.game.all_sprites:
                sprite.rect.x += Player_Speed
            self.x_change -= Player_Speed
            self.facing = "left"
        
        if keys[pygame.K_RIGHT]:
            for sprite in self.game.all_sprites:
                sprite.rect.x -= Player_Speed
            self.x_change += Player_Speed
            self.facing = "right"

        if keys[pygame.K_UP]:
            for sprite in self.game.all_sprites:
                sprite.rect.y += Player_Speed
            self.y_change -= Player_Speed
            self.facing = "up"

        if keys[pygame.K_DOWN]:
            for sprite in self.game.all_sprites:
                sprite.rect.y -= Player_Speed
            self.y_change += Player_Speed
            self.facing = "down"

    def collide_blocks(self, direction):
        if direction == 'x':
            hits = pygame.sprite.spritecollide(self, self.game.blocks, False)
            if hits:
                if self.x_change > 0:
                    for sprite in self.game.all_sprites:
                        sprite.rect.x += Player_Speed
                    self.rect.x = hits[0].rect.left - self.rect.width
                if self.x_change < 0:
                    for sprite in self.game.all_sprites:
                        sprite.rect.x -= Player_Speed
                    self.rect.x = hits[0].rect.right

        if direction == 'y':
            hits = pygame.sprite.spritecollide(self, self.game.blocks, False)
            if hits:
                if self.y_change > 0:
                    for sprite in self.game.all_sprites:
                        sprite.rect.y += Player_Speed
                    self.rect.y = hits[0].rect.top - self.rect.height
                if self.y_change < 0:
                    for sprite in self.game.all_sprites:
                        sprite.rect.y -= Player_Speed
                    self.rect.y = hits[0].rect.bottom
    
    def animate(self):               
        if self.facing == "down":
            if self.y_change == 0:
                self.image = self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = self.down_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "up":
            if self.y_change == 0:
                self.image = self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = self.up_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "left":
            if self.x_change == 0:
                self.image = self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = self.left_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "right":
            if self.x_change == 0:
                self.image = self.game.character_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = self.right_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1

##MOBS##
class Zombie(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        self._layer = Enemy_Layer
        self.groups = self.game.all_sprites, self.game.enemies
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.x_change = 0
        self.y_change = 0

        self.facing="up"
        self.animation_loop = 1
        self.movement_loop = 0
        self.max_travel = 1*Tilesize

        self.image = self.game.zombie_spritesheet.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    def update(self):
        self.movement()
        self.animate()
        
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        
        self.x_change = 0
        self.y_change = 0
    
    def movement(self):
        if self.facing == "left":
            self.x_change -= Zombie_Speed
            self.movement_loop -= 1
            if self.movement_loop <= -self.max_travel:
                    self.facing = "down"

        if self.facing == "down":
            self.y_change += Zombie_Speed
            self.movement_loop += 1
            if self.movement_loop >= self.max_travel:
                self.facing = "right"
    
        if self.facing == "right":
            self.x_change += Zombie_Speed
            self.movement_loop -= 1
            if self.movement_loop <= -self.max_travel:
                    self.facing = "up"

        if self.facing == "up":
            self.y_change -= Zombie_Speed
            self.movement_loop += 1
            if self.movement_loop >= self.max_travel:
                self.facing = "left"
   
    def animate(self):
        down_animations = [self.game.zombie_spritesheet.get_sprite(0, 0, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(64, 0, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(0, 0, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(128, 0, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(0, 0, self.width, self.height),]

        up_animations =  [self.game.zombie_spritesheet.get_sprite(0, 64, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(64, 64, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(0, 64, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(128, 64, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(0, 64, self.width, self.height),]

        left_animations = [self.game.zombie_spritesheet.get_sprite(0, 128, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(64, 128, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(0, 128, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(128, 128, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(0, 128, self.width, self.height),]

        right_animations = [self.game.zombie_spritesheet.get_sprite(0, 192, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(64, 192, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(0, 192, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(128, 192, self.width, self.height),
        self.game.zombie_spritesheet.get_sprite(0, 192, self.width, self.height),]
                
        if self.facing == "down":
            if self.y_change == 0:
                self.image = self.game.zombie_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = down_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.05
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "up":
            if self.y_change == 0:
                self.image = self.game.zombie_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = up_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.05
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "left":
            if self.x_change == 0:
                self.image = self.game.zombie_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = left_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.05
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "right":
            if self.x_change == 0:
                self.image = self.game.zombie_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = right_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.05
                if self.animation_loop >= 5:
                    self.animation_loop = 1

class Ghost(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        self._layer = Enemy_Layer
        self.groups = self.game.all_sprites, self.game.enemies
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.x_change = 0
        self.y_change = 0

        self.facing="down"
        self.animation_loop = 1
        self.movement_loop = 0
        self.max_travel = 0.4*Tilesize

        self.image = self.game.ghost_spritesheet.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    def update(self):
        self.movement()
        self.animate()
        
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        
        self.x_change = 0
        self.y_change = 0
  
    def movement(self):
        if self.facing == "left":
            self.x_change -= Ghost_Speed
            self.movement_loop -= 1
            if self.movement_loop <= -self.max_travel:
                    self.facing = "down"

        if self.facing == "down":
            self.y_change += Ghost_Speed
            self.movement_loop += 1
            if self.movement_loop >= self.max_travel:
                self.facing = "right"
    
        if self.facing == "right":
            self.x_change += Ghost_Speed
            self.movement_loop -= 1
            if self.movement_loop <= -self.max_travel:
                    self.facing = "up"

        if self.facing == "up":
            self.y_change -= Ghost_Speed
            self.movement_loop += 1
            if self.movement_loop >= self.max_travel:
                self.facing = "left"

    def animate(self):
        down_animations = [self.game.ghost_spritesheet.get_sprite(0, 0, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(64, 0, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(0, 0, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(128, 0, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(0, 0, self.width, self.height),]

        up_animations =  [self.game.ghost_spritesheet.get_sprite(0, 64, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(64, 64, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(0, 64, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(128, 64, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(0, 64, self.width, self.height),]

        left_animations = [self.game.ghost_spritesheet.get_sprite(0, 128, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(64, 128, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(0, 128, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(128, 128, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(0, 128, self.width, self.height),]

        right_animations = [self.game.ghost_spritesheet.get_sprite(0, 192, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(64, 192, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(0, 192, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(128, 192, self.width, self.height),
        self.game.ghost_spritesheet.get_sprite(0, 192, self.width, self.height),]
                
        if self.facing == "down":
            if self.y_change == 0:
                self.image = self.game.ghost_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = down_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.025
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "up":
            if self.y_change == 0:
                self.image = self.game.ghost_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = up_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.025
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "left":
            if self.x_change == 0:
                self.image = self.game.ghost_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = left_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.025
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "right":
            if self.x_change == 0:
                self.image = self.game.ghost_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = right_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.025
                if self.animation_loop >= 5:
                    self.animation_loop = 1

class Werewolf(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        self._layer = Enemy_Layer
        self.groups = self.game.all_sprites, self.game.enemies
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.x_change = 0
        self.y_change = 0

        self.facing="up"
        self.animation_loop = 1
        self.movement_loop = 0
        self.max_travel = 1*Tilesize

        self.image = self.game.werewolf_spritesheet.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    def update(self):
        self.movement()
        self.animate()
        
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        
        self.x_change = 0
        self.y_change = 0
    
    def movement(self):
        if self.facing == "down":
            self.y_change += Werewolf_Speed
            self.movement_loop -= 1
            if self.movement_loop <= -self.max_travel:
                self.facing = "up"
    
        if self.facing == "up":
            self.y_change -= Werewolf_Speed
            self.movement_loop += 1
            if self.movement_loop >= self.max_travel:
                self.facing = "down"
   
    def animate(self):
        down_animations = [self.game.werewolf_spritesheet.get_sprite(0, 0, self.width, self.height),
        self.game.werewolf_spritesheet.get_sprite(64, 0, self.width, self.height),
        self.game.werewolf_spritesheet.get_sprite(0, 0, self.width, self.height),
        self.game.werewolf_spritesheet.get_sprite(128, 0, self.width, self.height),
        self.game.werewolf_spritesheet.get_sprite(0, 0, self.width, self.height),]

        up_animations =  [self.game.werewolf_spritesheet.get_sprite(0, 64, self.width, self.height),
        self.game.werewolf_spritesheet.get_sprite(64, 64, self.width, self.height),
        self.game.werewolf_spritesheet.get_sprite(0, 64, self.width, self.height),
        self.game.werewolf_spritesheet.get_sprite(128, 64, self.width, self.height),
        self.game.werewolf_spritesheet.get_sprite(0, 64, self.width, self.height),]
              
        if self.facing == "down":
            if self.y_change == 0:
                self.image = self.game.werewolf_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = down_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "up":
            if self.y_change == 0:
                self.image = self.game.werewolf_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = up_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1

class Imp(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        self._layer = Enemy_Layer
        self.groups = self.game.all_sprites, self.game.enemies
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.x_change = 0
        self.y_change = 0

        self.facing="down"
        self.animation_loop = 1
        self.movement_loop = 0
        self.max_travel = 1*Tilesize

        self.image = self.game.imp_spritesheet.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    def update(self):
        self.movement()
        self.animate()
        
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        
        self.x_change = 0
        self.y_change = 0
    
    def movement(self):
        if self.facing == "down":
            self.y_change += Imp_Speed
            self.movement_loop -= 1
            if self.movement_loop <= -self.max_travel:
                self.facing = "up"
    
        if self.facing == "up":
            self.y_change -= Imp_Speed
            self.movement_loop += 1
            if self.movement_loop >= self.max_travel:
                self.facing = "down"
   
    def animate(self):
        down_animations = [self.game.imp_spritesheet.get_sprite(0, 0, self.width, self.height),
        self.game.imp_spritesheet.get_sprite(64, 0, self.width, self.height),
        self.game.imp_spritesheet.get_sprite(0, 0, self.width, self.height),
        self.game.imp_spritesheet.get_sprite(128, 0, self.width, self.height),
        self.game.imp_spritesheet.get_sprite(0, 0, self.width, self.height),]

        up_animations =  [self.game.imp_spritesheet.get_sprite(0, 64, self.width, self.height),
        self.game.imp_spritesheet.get_sprite(64, 64, self.width, self.height),
        self.game.imp_spritesheet.get_sprite(0, 64, self.width, self.height),
        self.game.imp_spritesheet.get_sprite(128, 64, self.width, self.height),
        self.game.imp_spritesheet.get_sprite(0, 64, self.width, self.height),]
              
        if self.facing == "down":
            if self.y_change == 0:
                self.image = self.game.imp_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = down_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "up":
            if self.y_change == 0:
                self.image = self.game.imp_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = up_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1

class Vampire(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        self._layer = Enemy_Layer
        self.groups = self.game.all_sprites, self.game.enemies
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.x_change = 0
        self.y_change = 0

        self.facing="right"
        self.animation_loop = 1
        self.movement_loop = 0
        self.max_travel = 1*Tilesize

        self.image = self.game.vampire_spritesheet.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    def update(self):
        self.movement()
        self.animate()
        
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        
        self.x_change = 0
        self.y_change = 0
    
    def movement(self):
        if self.facing == "right":
            self.x_change += Vampire_Speed
            self.movement_loop -= 1
            if self.movement_loop <= -self.max_travel:
                self.facing = "left"
    
        if self.facing == "left":
            self.x_change -= Vampire_Speed
            self.movement_loop += 1
            if self.movement_loop >= self.max_travel:
                self.facing = "right"

   
    def animate(self):
        left_animations = [self.game.vampire_spritesheet.get_sprite(0, 128, self.width, self.height),
        self.game.vampire_spritesheet.get_sprite(64, 128, self.width, self.height),
        self.game.vampire_spritesheet.get_sprite(0, 128, self.width, self.height),
        self.game.vampire_spritesheet.get_sprite(128, 128, self.width, self.height),
        self.game.vampire_spritesheet.get_sprite(0, 128, self.width, self.height),]

        right_animations = [self.game.vampire_spritesheet.get_sprite(0, 192, self.width, self.height),
        self.game.vampire_spritesheet.get_sprite(64, 192, self.width, self.height),
        self.game.vampire_spritesheet.get_sprite(0, 192, self.width, self.height),
        self.game.vampire_spritesheet.get_sprite(128, 192, self.width, self.height),
        self.game.vampire_spritesheet.get_sprite(0, 192, self.width, self.height),]
                
        if self.facing == "left":
            if self.x_change == 0:
                self.image = self.game.vampire_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = left_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "right":
            if self.x_change == 0:
                self.image = self.game.vampire_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = right_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1      

class Skeleton(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        self._layer = Enemy_Layer
        self.groups = self.game.all_sprites, self.game.enemies
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.x_change = 0
        self.y_change = 0

        self.facing="left"
        self.animation_loop = 1
        self.movement_loop = 0
        self.max_travel = 1*Tilesize

        self.image = self.game.skeleton_spritesheet.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    def update(self):
        self.movement()
        self.animate()
        
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        
        self.x_change = 0
        self.y_change = 0
    
    def movement(self):
        if self.facing == "right":
            self.x_change += Skeleton_Speed
            self.movement_loop -= 1
            if self.movement_loop <= -self.max_travel:
                self.facing = "left"
    
        if self.facing == "left":
            self.x_change -= Skeleton_Speed
            self.movement_loop += 1
            if self.movement_loop >= self.max_travel:
                self.facing = "right"

   
    def animate(self):
        left_animations = [self.game.skeleton_spritesheet.get_sprite(0, 128, self.width, self.height),
        self.game.skeleton_spritesheet.get_sprite(64, 128, self.width, self.height),
        self.game.skeleton_spritesheet.get_sprite(0, 128, self.width, self.height),
        self.game.skeleton_spritesheet.get_sprite(128, 128, self.width, self.height),
        self.game.skeleton_spritesheet.get_sprite(0, 128, self.width, self.height),]

        right_animations = [self.game.skeleton_spritesheet.get_sprite(0, 192, self.width, self.height),
        self.game.skeleton_spritesheet.get_sprite(64, 192, self.width, self.height),
        self.game.skeleton_spritesheet.get_sprite(0, 192, self.width, self.height),
        self.game.skeleton_spritesheet.get_sprite(128, 192, self.width, self.height),
        self.game.skeleton_spritesheet.get_sprite(0, 192, self.width, self.height),]
                
        if self.facing == "left":
            if self.x_change == 0:
                self.image = self.game.skeleton_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = left_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1

        if self.facing == "right":
            if self.x_change == 0:
                self.image = self.game.skeleton_spritesheet.get_sprite(0, 0, self.width, self.height)
            else:
                self.image = right_animations[math.floor(self.animation_loop)]
                self.animation_loop += 0.1
                if self.animation_loop >= 5:
                    self.animation_loop = 1      


class Candy(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.left = LeftCandy
        self.groups = self.game.all_sprites, self.game.candy
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        CandyType = random.randint(0,3)
        CandyTypeSprite=CandyType*Tilesize

        self.image =  self.game.candy_spritesheet.get_sprite(CandyTypeSprite, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    def update(self):
        self.collide_candy()

    def collide_candy(self):
        pick = pygame.sprite.spritecollide(self, self.game.player, False)
        if pick:
            self.kill()


##TERRAIN"
class TreeForest(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(128, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class TreeTop(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(64, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class Tree(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Decoration_Layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(64, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class TreeBot(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(64, 64, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class Bush(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(128, 64, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class FenceX(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(64, 128, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class FenceY(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(64, 192, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class LampTop(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Decoration_Layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(128, 128, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class LampBot(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(128, 192, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

###House###
class House1(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(192, 192, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class House2(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(192, 128, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class House3(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(192, 64, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class House4(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(256, 128, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class House5(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(256, 64, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
    
class House6(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(384, 192, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class House7(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(448, 192, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class House8(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(384, 128, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class House9(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(384, 64, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class HouseD(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(256, 192, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class HouseWB(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(320, 192, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class HouseWM(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(320, 128, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class HouseWT(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Block_Layer
        self.groups = self.game.all_sprites, self.game.blocks
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(320, 64, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class Roof1(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Decoration_Layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(192, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class Roof2(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Decoration_Layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(256, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class Roof3(pygame.sprite.Sprite):
    def __init__(self, game, x, y):

        self.game = game
        self._layer = Decoration_Layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(384, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

###Ground###
class Grass(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        self._layer = Ground_Layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(0, 0, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class Street(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        self._layer = Ground_Layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(0, 64, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class SideWalk(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        self._layer = Ground_Layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(0, 128, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class Path(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        self._layer = Ground_Layer
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        self.x = x * Tilesize
        self.y = y * Tilesize
        self.width =  Tilesize
        self.height =  Tilesize

        self.image =  self.game.terrain_spritesheet.get_sprite(0, 192, self.width, self.height)

        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

class button():
    def __init__(self, x, y, width, height, fg, bg, content, size):
        self.font = pygame.font.Font("bit.ttf", size)
        self.content = content

        self.x = x
        self.y = y
        self.width = width
        self.height =height

        self.fg = fg
        self.bg =bg
        
        self.image = pygame.Surface((self.width, self.height))
        self.image.fill(self.bg)
        self.rect = self.image.get_rect()

        self.rect.x = self.x
        self.rect.y = self.y
        
        self.text = self.font.render(self.content, True, self.fg)
        self.text_rect = self.text.get_rect(center=(self.width/2, self.height/2))
        self.image.blit(self.text, self.text_rect)
    
    def is_pressed(self, pos, pressed):
        if self.rect.collidepoint(pos):
            if pressed[0]:
                return True
            return False
        return False
